﻿namespace _2._2012.IntroductionAPI.Dtos.UserDto
{
    public class UpdateUserDto
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }
}
