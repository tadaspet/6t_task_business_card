﻿using III.DataBase.Exam.DataBase.Models;

namespace III.DataBase.Exam
{
    //public class FacultyCourse
    //{
    //    public int FacultyId { get; set; }
    //    public int CourseId { get; set; }
    //    public Faculty Faculty { get; set; }
    //    public Course Course { get; set; }

    //}
}